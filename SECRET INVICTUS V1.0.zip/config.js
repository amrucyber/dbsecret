module.exports = {
  TOKEN_SECRET: "token lo",
};
