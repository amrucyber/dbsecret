const { Telegraf, Markup, session } = require("telegraf"); 
const fs = require("fs");
const path = require("path");
const moment = require("moment-timezone");
const {
  makeWASocket,
  makeInMemoryStore,
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
  DisconnectReason,
  generateWAMessageFromContent,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const chalk = require("chalk");
const axios = require("axios");
const { TOKEN_SECRET } = require("./config");
const crypto = require("crypto");
const premiumFile = "./database/premiumuser.json";
const adminFile = "./database/adminuser.json";
const ownerFile = "./database/owneruser.json";
const TOKENS_FILE = "./tokens.json";
const sessionPath = './session';
let bots = [];

const bot = new Telegraf(TOKEN_SECRET);


bot.use(session());

let sock = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = "";
const usePairingCode = true;

/// ------ ( const img ) ------ \\\
const image = "https://files.catbox.moe/bijqp4.jpg";

/// ------ ( Const Runtime ) ------ \\\
const getUptime = () => {
  const uptimeSeconds = process.uptime();
  const hours = Math.floor(uptimeSeconds / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = Math.floor(uptimeSeconds % 60);

  return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) =>
  new Promise((resolve) => {
    const rl = require("readline").createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    rl.question(query, (answer) => {
      rl.close();
      resolve(answer);
    });
  });

function formatTime(ms) {
  const totalSeconds = Math.ceil(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  if (minutes > 0) {
    return `${minutes} menit ${seconds} detik`;
  }
  return `${seconds} detik`;
}


/// ------ ( Function Date ) ------ \\\
function getCurrentDate() {
  const now = new Date();
  const options = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  };
  return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}

/// ----- ( Function ensureDataBase ) -------- \\\
function ensureDatabaseFolder() {
  const dbFolder = path.join(__dirname, "database");
  if (!fs.existsSync(dbFolder)) {
    fs.mkdirSync(dbFolder, { recursive: true });
  }
}


/// ------- ( Ghitub token ) -------- \\\
const GITHUB_TOKEN_LIST_URL =
  "RAW_LU'";


async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens;
  } catch (error) {
    console.error(chalk.red("GAGAL MENGAMBIL DATA DARI GITHUB ", error.message));
    return [];
  }
}


async function validateToken() {
  console.log(chalk.blue("Process Check Token"));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(tokenBot)) {
    console.log(chalk.bold.red(`
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠁⠀⠀⠈⠉⠙⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⢀⣠⣤⣤⣤⣤⣄⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⠁⠀⠀⠀⠀⠾⣿⣿⣿⣿⠿⠛⠉⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⡏⠀⠀⠀⣤⣶⣤⣉⣿⣿⡯⣀⣴⣿⡗⠀⠀⠀⠀⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⡈⠀⠀⠉⣿⣿⣶⡉⠀⠀⣀⡀⠀⠀⠀⢻⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⡇⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⢸⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠉⢉⣽⣿⠿⣿⡿⢻⣯⡍⢁⠄⠀⠀⠀⣸⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠐⡀⢉⠉⠀⠠⠀⢉⣉⠀⡜⠀⠀⠀⠀⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⠿⠁⠀⠀⠀⠘⣤⣭⣟⠛⠛⣉⣁⡜⠀⠀⠀⠀⠀⠛⠿⣿⣿⣿
⡿⠟⠛⠉⠉⠀⠀⠀⠀⠀⠀⠀⠈⢻⣿⡀⠀⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠁⠀⠁⠀⠀⠀⠀⠀⠀⠀
Tokens Is Not Registered\nPlease Contact @amrustoreoffc In Telegram For Registration Tokens`));
    process.exit(1);
  }

  console.log(chalk.cyan(`Thanks For Purchasing This Script`));
  startBot();
}

/// ------- ( console log ) ------- \\\
function startBot() {
  console.log(
    chalk.cyan(`
⠀⠀⠀⠀⠀⠀⠀⣀⡄⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀
⠀⠀⠀⠀⠀⠀⠐⢿⠓⠀⢀⡴⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠹⡒⠤⣀⡀⠀⢀⡴⠋⢠⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠱⡀⠀⠉⠑⠋⠀⠀⣸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⠀
⠀⠀⠀⠀⢱⡄⠀⠀⠀⠀⠀⠉⠒⠤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀
⠀⠀⠀⡴⠋⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣈⠵⠦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⠀
⢀⡤⠋⣀⣀⣀⣤⠀⠀⠀⢰⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀
⠈⠉⠁⠀⠀⠀⠀⢧⠀⠀⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢐⣶⣆⠀⠀⢠⠈⢇⢰⠃⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⣰⡄⠀⠀⠀⠀⠀⠀
⠀⠈⠙⠀⠀⠀⣏⣧⠈⠟⠀⠀⠀⠀⠀⠀⠽⡿⠆⠀⠀⠀⢀⣿⣿⣦⣶⣶⠟⠀⠀
⠀⠀⠀⠀⣀⣸⣿⣯⢧⠤⢤⣤⣴⠦⠀⠀⠀⠁⠀⠀⠛⠿⣿⣿⣿⣿⣿⡁⠀⠀⠀
⠀⠙⠯⡻⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠰⣄⣠⡇⠀⠀⠀⠀⢸⣿⡿⠛⠛⠿⣆⠀⠀
⠀⠀⠀⠈⢻⣿⣿⣿⣿⣿⠁⠀⠀⠀⣠⢿⣿⠟⠒⠀⠀⠀⠸⠊⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⡾⣿⠿⠺⢝⡯⢧⠀⠀⠀⠀⠀⠻⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢼⠓⠁⠀⠀⠀⠉⠺⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⢿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡜⠈⡇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢟⡒⠒⠛⠁⠀⠘⠒⠒⢲⡶⠂⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⡆⠀⠈⢢⠀⠀⠀⠀⡤⠚⠁⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⠉⠀⢠⠇⢀⡤⣀⠀⢳⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡿⠊⠁⠀⠈⠳⣼⡄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡄⠀⣀⠀⠀⢀⣄⡀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠶⢾⣿⣟⠁⠀⠀⠺⡟⠃
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡏⢉⠓⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

Token Valids ( 🫆 )
Devoloper : @amrustoreoffc
Thanks For Purchasing This Script
`));
}

startBot();

/// ------ ( console log function WhatsApp ) ------- \\\
const startSesi = async () => {
  const { state, saveCreds } = await useMultiFileAuthState("./session");
  const { version } = await fetchLatestBaileysVersion();

  const connectionOptions = {
    version,
    keepAliveIntervalMs: 30000,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }), // Log level diubah ke "info"
    auth: state,
    browser: ["Mac OS", "Safari", "10.15.7"],
    getMessage: async (key) => ({
      conversation: "P", // Placeholder, you can change this or remove it
    }),
  };

  sock = makeWASocket(connectionOptions);

  sock.ev.on("creds.update", saveCreds);
  

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "open") {
      isWhatsAppConnected = true;
      console.log(
        chalk.white.bold(`
 Sclu° Ϟ °Connection
 ${chalk.green.bold("Whatsapp Connected")}
`)
      );
    }

    if (connection === "close") {
      const shouldReconnect =
        lastDisconnect?.error?.output?.statusCode !==
        DisconnectReason.loggedOut;
      console.log(
        chalk.white.bold(`
 Sclu° Ϟ °Connection
 ${chalk.red.bold("Whatsapp Disconnected")}
`),
        shouldReconnect
          ? chalk.white.bold(`
 Sclu° Ϟ °Connection
 ${chalk.red.bold("Hubungkan Ulang")}
`)
          : ""
      );
      if (shouldReconnect) {
        startSesi();
      }
      isWhatsAppConnected = false;
    }
  });
};

const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    ctx.reply("Sender Not Connected, Please /connect");
    return;
  }
  next();
};
/// ---- ( const loadJson ) ----- \\\
const loadJSON = (file) => {
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, "utf8"));
};


/// ----- ( const saveJson ) ------- \\\
const saveJSON = (file, data) => {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
};



//// -------- ( Function Delete Session ) -------- \\\
function deleteSession() {
  if (fs.existsSync(sessionPath)) {
    const stat = fs.statSync(sessionPath);

    if (stat.isDirectory()) {
      fs.readdirSync(sessionPath).forEach(file => {
        fs.unlinkSync(path.join(sessionPath, file));
      });
      fs.rmdirSync(sessionPath);
      console.log('Folder session berhasil dihapus.');
    } else {
      fs.unlinkSync(sessionPath);
      console.log('File session berhasil dihapus.');
    }

    return true;
  } else {
    console.log('Session tidak ditemukan.');
    return false;
  }
}


/// Muat ID owner dan pengguna premium \\\
let ownerUsers = loadJSON(ownerFile);
let adminUsers = loadJSON(adminFile);
let premiumUsers = loadJSON(premiumFile);



/// ---- ( Middleware untuk memeriksa apakah pengguna adalah owner ) ------- \\\
const checkOwner = (ctx, next) => {
  if (!ownerUsers.includes(ctx.from.id.toString())) {
    return ctx.reply("Owner Acces\nPlease Contact @amrustoreoffc For Purchasing Owner Acces");
         }        
    next();
};

const checkAdmin = (ctx, next) => {
  if (!adminUsers.includes(ctx.from.id.toString())) {
  return ctx.reply("Admin Acces\nPlease Contact @amrustoreoffc For Purchasing Admin Acces");
       }
    next();
};


/// --- ( Middleware untuk memeriksa apakah pengguna adalah premium ) ---- \\\

const checkPremium = (ctx, next) => {
  if (!premiumUsers.includes(ctx.from.id.toString())) {
    return ctx.reply("Owner Acces\nPlease Contact @amrustoreoffc For Purchasing Owner Acces");
     }
    next();
};


/// -------- ( const nambah admin ) -------- \\\
const addAdmin = (userId) => {
  if (!adminList.includes(userId)) {
    adminList.push(userId);
    saveAdmins();
  }
};


/// --------- ( const delete admin ) ----------- \\\
const removeAdmin = (userId) => {
  adminList = adminList.filter((id) => id !== userId);
  saveAdmins();
};


/// -------- ( const list admin ) ------- \\\
const saveAdmins = () => {
  fs.writeFileSync("./database/admins.json", JSON.stringify(adminList));
};


/// ------- ( const case admin ) -------- \\\
const loadAdmins = () => {
  try {
    const data = fs.readFileSync("./database/admins.json");
    adminList = JSON.parse(data);
  } catch (error) {
    console.error(chalk.red("Gagal memuat daftar admin:"), error);
    adminList = [];
  }
};



/// ----- ( function sleep ( mengatur kecepatan mengirim bug )) ----- \\\
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/// -------- ( menu utama ) --------- \\\
bot.start(async (ctx) => {
    const menuMessage = `
<blockquote>( 🕸️ ) 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

─ ( 🐾 ) 私は WhatsApp でクラッシュを作成するために使用される Telegram ボットです。

Ϟ Bot Name : 𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬
Ϟ Version : 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝟏.𝟎
Ϟ Devoloper : @amrustoreoffc
Ϟ Language : Javascript
Ϟ Username : ${ctx.from.first_name}

<blockquote>( 🕷️ ) 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>`;


    const keyboard = [
          [{ text: "Trash ⵢ Menu", callback_data: "/bug" }],
          [
            { text: "Controls ⵢ Menu", callback_data: "/controls" },
            { text: "Thanks ⵢ To", callback_data: "/tqto" },
          ],
          [{ text: "Owner ⵢ Script", url: "https://t.me/amrustoreoffc" }],
        ];

    ctx.replyWithPhoto(image, {
        caption: menuMessage,
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: keyboard
        }
    });
  await ctx.replyWithAudio(
    { source: fs.createReadStream("./image/secret invictus.mp3") },
    {
      title: "𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬 ¡?",
      caption: "𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬 ¡?",
      performer: "𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬",
    }
  );
});

bot.action('/start', async (ctx) => {
    const menuMessage = `
<blockquote>( 🕸️ ) 𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

─ ( 🐾 ) 私は WhatsApp でクラッシュを作成するために使用される Telegram ボットです。

Ϟ Bot Name : 𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬
Ϟ Version : 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝟏.𝟎
Ϟ Devoloper : @amrustoreoffc
Ϟ Language : Javascript
Ϟ Username : ${ctx.from.first_name}

<blockquote>( 🕷️ ) 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>`;

    const keyboard = [
          [{ text: "Trash ⵢ Menu", callback_data: "/bug" }],
          [
            { text: "Controls ⵢ Menu", callback_data: "/controls" },
            { text: "Thanks ⵢ To", callback_data: "/tqto" },
          ],
          [{ text: "Owner ⵢ Script", url: "https://t.me/amrustoreoffc" }],
        ];

    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: image,
            caption: menuMessage,
            parse_mode: "HTML",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/back', async (ctx) => {
    const menuMessage = `
<blockquote>( 🕸️ ) 𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

─ ( 🐾 ) 私は WhatsApp でクラッシュを作成するために使用される Telegram ボットです。

Ϟ Bot Name : 𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬
Ϟ Version : 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝟏.𝟎
Ϟ Devoloper : @amrustoreoffc
Ϟ Language : Javascript
Ϟ Username : ${ctx.from.first_name}

<blockquote>( 🕷️ ) 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>`;

    const keyboard = [
          [{ text: "Trash ⵢ Menu", callback_data: "/bug" }],
          [
            { text: "Controls ⵢ Menu", callback_data: "/controls" },
            { text: "Thanks ⵢ To", callback_data: "/tqto" },
          ],
          [{ text: "Owner ⵢ Script", url: "https://t.me/amrustoreoffc" }],
        ];

    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: image,
            caption: menuMessage,
            parse_mode: "HTML",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/controls', async (ctx) => {
    const controlsMenu = `
<blockquote>( 🕸️ ) 𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

─ ( 🐾 ) 私は WhatsApp でクラッシュを作成するために使用される Telegram ボットです。

Ϟ Bot Name : 𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬
Ϟ Version : 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝟏.𝟎
Ϟ Devoloper : @amrustoreoffc
Ϟ Language : Javascript
Ϟ Username : ${ctx.from.first_name}

<blockquote>Sclu° Ϟ °Controls</blockquote>
𖥂 /delsesi - delete sessions
𖥂 /connect - add sender number
𖥂 /addadmin - add admin users
𖥂 /deladmin - delete admin users
𖥂 /addprem - add premium users
𖥂 /delprem - delete premium users
`;

    const keyboard = [
        [
            {
                text: "Back ⵢ",
                callback_data: "/back"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(controlsMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/bug', async (ctx) => {
    const bugMenu = `
<blockquote>( 🕸️ ) 𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

─ ( 🐾 ) 私は WhatsApp でクラッシュを作成するために使用される Telegram ボットです。

Ϟ Bot Name : 𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬
Ϟ Version : 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝟏.𝟎
Ϟ Devoloper : @amrustoreoffc
Ϟ Language : Javascript
Ϟ Username : ${ctx.from.first_name}

<blockquote>𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬° Ϟ °Trash</blockquote>
𖥂 /delayandro - Delay Andro
𖥂 /delayios - Delay Ios
𖥂 /blankandro - Blank Andro
𖥂 /invisdelay - Delay Invis
`;

    const keyboard = [
        [
            {
                text: "Back ⵢ",
                callback_data: "/back"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(bugMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/tqto', async (ctx) => {
    const tqtoMenu = `
<blockquote>( 🕸️ ) 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

─ ( 🐾 ) 私は WhatsApp でクラッシュを作成するために使用される Telegram ボットです。

Ϟ Bot Name : 𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬
Ϟ Version : 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝟏.𝟎
Ϟ Devoloper : @amrustoreoffc
Ϟ Language : Javascript
Ϟ Username : ${ctx.from.first_name}

<blockquote>𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬° Ϟ °Support</blockquote>
𖥂 AmruStore - Dev 
`;

    const keyboard = [
        [
            {
                text: "Back ⵢ",
                callback_data: "/back"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(tqtoMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

/// ------ ( Plugins ) ------- \\\
bot.command("addadmin", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");

  if (args.length < 2) {
    return ctx.reply(
      "Example: /addadmin 123"
    );
  }

  const userId = args[1];

  if (adminUsers.includes(userId)) {
    return ctx.reply(`✅ User ${userId} already become admin.`);
  }

  adminUsers.push(userId);
  saveJSON(adminFile, adminUsers);

  return ctx.reply(`✅ Succes add ${userId} to admin`);
});

bot.command("addprem", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");



  if (args.length < 2) {
    return ctx.reply(
      "Example: /addprem 123"
    );
  }

  const userId = args[1];

  if (premiumUsers.includes(userId)) {
    return ctx.reply(
      `✅ User ${userId} already become premium.`
    );
  }

  premiumUsers.push(userId);
  saveJSON(premiumFile, premiumUsers);

  return ctx.reply(
    `✅ Succes add ${userId} to premium`
  );
});

bot.command("deladmin", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");

  if (args.length < 2) {
    return ctx.reply(
      "Example: /deladmin 123"
    );
  }

  const userId = args[1];

  if (!adminUsers.includes(userId)) {
    return ctx.reply(`User ${userId} tidak ada dalam daftar Admin.`);
  }

  adminUsers = adminUsers.filter((id) => id !== userId);
  saveJSON(adminFile, adminUsers);

  return ctx.reply(`🚫 Succes delete user ${userId} from admin.`);
});

bot.command("delprem", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");


  if (args.length < 2) {
    return ctx.reply(
      "Example: /delprem 123"
    );
  }

  const userId = args[1];

  if (!premiumUsers.includes(userId)) {
    return ctx.reply(`User ${userId} tidak ada dalam daftar premium.`);
  }

  premiumUsers = premiumUsers.filter((id) => id !== userId);
  saveJSON(premiumFile, premiumUsers);

  return ctx.reply(`🚫 Succes delete user ${userId} from premium.`);
});



/// ------ ( case cek akses pengguna ) ------- \\\
bot.command("cekprem", (ctx) => {
  const userId = ctx.from.id.toString();



  if (premiumUsers.includes(userId)) {
    return ctx.reply(`Premium Acces`);
  } else {
    return ctx.reply(`Not Premium`);
  }
});



/// -------- ( case pairing code ) -------- \\\
bot.command("connect", checkOwner, async (ctx) => {
  const date = getCurrentDate();
  const args = ctx.message.text.split(" ");

  if (args.length < 2) {
    return await ctx.reply(
      "Example: /connect 62xx"
    );
  }

  let phoneNumber = args[1];
  phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

  try {
    const code = await sock.requestPairingCode(phoneNumber, "XEVORZEL");
    const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

    await ctx.replyWithPhoto(image, {
      caption: `
<blockquote>𝐒𝐞𝐜𝐫𝐞𝐭 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬° Ϟ °Connection</blockquote>
𖥂 Number: ${phoneNumber}  
𖥂 Pairing Code: ${formattedCode}  
𖥂 Date : ${date}
`,

   parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "❌ Close", callback_data: "close" }]],
      },
    });
  } catch (error) {
  
 console.error(chalk.red("Gagal melakukan pairing:"), error);
    await ctx.reply(
      "❌ Gagal melakukan pairing !"
    );
  }
});



/// ------ ( hendle close ) ------- \\\
bot.action("close", async (ctx) => {
  try {
    await ctx.deleteMessage();
  } catch (error) {
    console.error(chalk.red("Gagal menghapus pesan:"), error);
  }
});



/// -------- ( case delete session ) -------- \\\
bot.command("delsesi", (ctx) => {
  const success = deleteSession();

  if (success) {
    ctx.reply("Session berhasil dihapus, Segera lakukan /restart lalu pairing kembali");
  } else {
    ctx.reply("Tidak ada session yang tersimpan saat ini.");
  }
});


/// --------- ( CASE BUG ) ---------- \\\
bot.command("delayandro", checkPremium, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;
  const chatId = ctx.chat.id;


  if (!q) {
    return ctx.reply(`Command /delayandro 60xx`);
  }

  let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  // Kirim pesan proses dimulai dan simpan messageId-nya
  const sentMessage = await ctx.sendPhoto(
    "https://files.catbox.moe/ccj43n.jpg",
    {
      caption: `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐬𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Sending Bugs...
𖥂 Progress : [░░░░░░░░░░] 0%

<blockquote>( 🦋 ) Xzell ⵢ Xopz</blockquote>
`,
      parse_mode: "HTML",
    }
  );

  // Progress bar bertahap
  const progressStages = [
    { text: "𖥂 Progress: [█░░░░░░░░░]10%", delay: 200 },
    { text: "𖥂 Progress: [███░░░░░░░]30%", delay: 200 },
    { text: "𖥂 Progress: [█████░░░░░]50%", delay: 100 },
    { text: "𖥂 Progress: [███████░░░]70%", delay: 100 },
    { text: "𖥂 Progress: [█████████░]90%", delay: 100 },
    { text: "𖥂 Progress: [██████████]100%", delay: 200 },
  ];

  // Jalankan progres bertahap
  for (const stage of progressStages) {
    await new Promise((resolve) => setTimeout(resolve, stage.delay));
    await ctx.editMessageCaption(
      `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐬𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Processing..
${stage.text}

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "HTML",
      }
    );
  }

  /// Eksekusi bug setelah progres selesai
  console.log(chalk.red(`Process Sending Bugs To ${target}`));

  //CMD LOPP 
  for (let i = 0; i < 800; i++) {
    await SuckIns(sock, target);
    await uiIos(sock, target);
    await FcUiFlows(sock, target);
    await CrashIp(sock, target);
    await sleep(1000)
  }
  // Update ke sukses + tombol cek target
  await ctx.editMessageCaption(
    `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐬𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Succesfully
𖥂 Progress: [██████████]100%

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
    {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Check ϟ Target", url: `https://wa.me/${q}` }],
        ],
      },
    }
  );
});
/////////---- CASE BUG 2 ----\\\\\\\\\\\\
bot.command("delayios",checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
    const chatId = ctx.chat.id;

    if (!q) {
      return ctx.reply(`command: /delayios 60xx`);
    }

    let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    // Kirim pesan proses dimulai dan simpan messageId-nya
    const sentMessage = await ctx.sendPhoto(
      "https://files.catbox.moe/ccj43n.jpg",
      {
        caption: `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Sending Bugs...
𖥂 Progress : [░░░░░░░░░░] 0%

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
        parse_mode: "HTML",
      }
    );

    // Progress bar bertahap
    const progressStages = [
      { text: "𖥂 Progress: [█░░░░░░░░░]10%", delay: 200 },
      { text: "𖥂 Progress: [███░░░░░░░]30%", delay: 200 },
      { text: "𖥂 Progress: [█████░░░░░]50%", delay: 100 },
      { text: "𖥂 Progress: [███████░░░]70%", delay: 100 },
      { text: "𖥂 Progress: [█████████░]90%", delay: 100 },
      { text: "𖥂 Progress: [██████████]100%", delay: 200 },
    ];

    // Jalankan progres bertahap
    for (const stage of progressStages) {
      await new Promise((resolve) => setTimeout(resolve, stage.delay));
      await ctx.editMessageCaption(
        `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Processing..
${stage.text}

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
        {
          chat_id: chatId,
          message_id: sentMessage.message_id,
          parse_mode: "HTML",
        }
      );
    }

    /// Eksekusi bug setelah progres selesai
    console.log(chalk.red(`Process Sending Bugs To ${target}`));

 //CMD LOPP 
    for (let i = 0; i < 200; i++) {
      await FcUiFlows(sock, target);
      await PayloadFcVisible(sock, target);
      await sleep(1000)
    }
    // Update ke sukses + tombol cek target
    await ctx.editMessageCaption(
      `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐢𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Succesfully
𖥂 Progress: [██████████]100%

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "Check ϟ Target", url: `https://wa.me/${q}` }],
          ],
        },
      }
    );
  }
);
//////////---- CASE BUG 3 ----\\\\\\\\\\\
bot.command("blankandro", checkWhatsAppConnection, checkPremium, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;
  const chatId = ctx.chat.id;

  if (!q) {
    return ctx.reply(`Command: /blankandro 60xx`);
  }

  let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const sentMessage = await ctx.sendPhoto(
   "https://files.catbox.moe/ccj43n.jpg",
    {
      caption: `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭  Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Sending Bugs...
𖥂 Progress : [░░░░░░░░░░] 0%

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
      parse_mode: "HTML",
    }
  );

  // Progress bar bertahap
  const progressStages = [
    { text: "𖥂 Progress: [█░░░░░░░░░]10%", delay: 200 },
    { text: "𖥂 Progress: [███░░░░░░░]30%", delay: 200 },
    { text: "𖥂 Progress: [█████░░░░░]50%", delay: 100 },
    { text: "𖥂 Progress: [███████░░░]70%", delay: 100 },
    { text: "𖥂 Progress: [█████████░]90%", delay: 100 },
    { text: "𖥂 Progress: [██████████]100%", delay: 200 },
  ];

  // Jalankan progres bertahap
  for (const stage of progressStages) {
    await new Promise((resolve) => setTimeout(resolve, stage.delay));
    await ctx.editMessageCaption(
      `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Processing..
${stage.text}

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "HTML",
      }
    );
  }

  /// Eksekusi bug setelah progres selesai
  console.log(chalk.red(`Process Sending Bugs To ${target}`));

 //CMD LOPP 
  for (let i = 0; i < 200; i++) {
    await betadelayNew(sock, target);
    await DelayNative(sock, target);
    await DelayNative(sock, target);
    await sleep(500);
  }
  // Update ke sukses + tombol cek target
  await ctx.editMessageCaption(
    `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Succesfully
𖥂 Progress: [██████████]100%

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
    {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Check ϟ Target", url: `https://wa.me/${q}` }],
        ],
      },
    }
  );
});
/////////----- CASE BUG 4 -----\\\\\\\\\\\
bot.command("invisdelay", checkWhatsAppConnection, checkPremium, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;
  const chatId = ctx.chat.id;

  if (!q) {
    return ctx.reply(`Command : /invisdelay 60xx`);
  }

  let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const sentMessage = await ctx.sendPhoto(
   " https://files.catbox.moe/ccj43n.jpg",
    {
      caption: `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Sending Bugs...
𖥂 Progress : [░░░░░░░░░░] 0%

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
      parse_mode: "HTML",
    }
  );

  // Progress bar bertahap
  const progressStages = [
    { text: "𖥂 Progress: [█░░░░░░░░░]10%", delay: 200 },
    { text: "𖥂 Progress: [███░░░░░░░]30%", delay: 200 },
    { text: "𖥂 Progress: [█████░░░░░]50%", delay: 100 },
    { text: "𖥂 Progress: [███████░░░]70%", delay: 100 },
    { text: "𖥂 Progress: [█████████░]90%", delay: 100 },
    { text: "𖥂 Progress: [██████████]100%", delay: 200 },
  ];

  // Jalankan progres bertahap
  for (const stage of progressStages) {
    await new Promise((resolve) => setTimeout(resolve, stage.delay));
    await ctx.editMessageCaption(
      `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Processing..
${stage.text}

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "HTML",
      }
    );
  }

  /// Eksekusi bug setelah progres selesai
  console.log(chalk.red(`Process Sending Bugs To ${target}`));

 //CMD LOPP 
  for (let i = 0; i < 50; i++) {
    await Efce(sock, target);
    await Efce(sock, target);
    await Efce(sock, target);
    await sleep(1000)
  }
  // Update ke sukses + tombol cek target
  await ctx.editMessageCaption(
    `
<blockquote>𖣂 𝐒𝐞𝐜𝐫𝐞𝐭 Ϟ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>

𖥂 Target: ${q}
𖥂 Status: Succesfully
𖥂 Progress: [██████████]100%

<blockquote>( 🦋 ) 𝐒𝐞𝐜𝐫𝐞𝐭 ⵢ 𝐈𝐧𝐯𝐢𝐜𝐭𝐮𝐬</blockquote>
`,
    {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "Check ϟ Target", url: `https://wa.me/${q}` }]],
      },
    }
  );
});

// --------------( FUNCTION BUGS ) -----------------------\\


// ------------ ( END FUNCTION BUGS ) -------------- \\

// --- Jalankan Bot ---

(async () => {
  console.clear();
  console.log("🚀 Memulai sesi WhatsApp...");
  startSesi();

  console.log("Succes Connected 🕷️");
  bot.launch();

  // Membersihkan konsol sebelum menampilkan pesan sukses
  console.clear();
  console.log(
    chalk.bold.white(`\n

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀`)
  );
})();
